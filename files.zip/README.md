# ArtisanHub — Smart Surge

AI-powered, voice-first market access for rural artisans.
**Snap. Speak. Sell.**

- Team: Smart Surge (Team ID 177644)
- Problem Statement: 26090, AI-driven market linkage and smart catalogue mobile app for marginalized artisans (Software)
- Live prototype: https://intelligent-artisan-hub-flow.base44.app

## Repository layout

| Path | Contents |
|---|---|
| `deck/Smart_Surge.pptx` | Idea-submission presentation (8 slides) |
| `build/make.js` | Script that regenerates the deck with pptxgenjs |
| `build/assets/` | Logos and photos used by the script |

## Rebuild the deck

```bash
cd build
npm install
npm run build   # writes ../deck/Smart_Surge.pptx
```

## Placeholders to complete

- Team member names, team leader email and phone, college name (slide 1)
- GitHub repo and demo video links (slide 8)
